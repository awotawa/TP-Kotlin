package com.example.tp

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class SignInActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in)
    }

    fun onClick(view: View?) {
        when(view?.id){
            R.id.signInButton ->{
                val intent : Intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
            }
        }
    }
}